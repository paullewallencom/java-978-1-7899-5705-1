package com.packt.learnjava.ch09_jvm.example;

public class ExampleClass {
    public static int multiplyByTwo(int i){
        return 2 * i;
    }
}
