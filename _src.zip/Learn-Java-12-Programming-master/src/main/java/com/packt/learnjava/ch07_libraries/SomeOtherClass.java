package com.packt.learnjava.ch07_libraries;

public class SomeOtherClass {
    public int getValue(){
        return 2;
    }
}
