package com.packt.learnjava.ch02_oop.hiding;

public class C {
    public static String NAME = "class C";
    public static void method(){
        System.out.println("class C");
    }
    public String name1 = "class C";
}
